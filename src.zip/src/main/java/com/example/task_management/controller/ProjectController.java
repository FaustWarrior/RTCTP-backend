package com.example.task_management.controller;

import com.example.task_management.model.Project;
import com.example.task_management.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping
    public ResponseEntity<Project> createProject(@RequestBody Project project) {
        return ResponseEntity.ok(projectService.createProject(project));
    }

    @GetMapping("/user/{userId}")
    public List<Project> getProjectsForUser(@PathVariable Long userId) {
        return projectService.getProjectsForUser(userId);
    }
}
