package com.example.task_management.graphql.resolver;

import com.example.task_management.model.Project;
import com.example.task_management.service.ProjectService;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProjectResolver {

    @Autowired
    private ProjectService projectService;

    public DataFetcher<Project> getProjectById() {
        return dataFetchingEnvironment -> {
            String id = dataFetchingEnvironment.getArgument("id");
            return projectService.getProjectById(id);
        };
    }

    public DataFetcher<List<Project>> getProjectsForUser() {
        return dataFetchingEnvironment -> {
            Long userId = dataFetchingEnvironment.getArgument("userId");
            return projectService.getProjectsForUser(userId);
        };
    }

    public DataFetcher<Project> createProject() {
        return dataFetchingEnvironment -> {
            Project project = dataFetchingEnvironment.getArgument("project");
            return projectService.createProject(project);
        };
    }
}
