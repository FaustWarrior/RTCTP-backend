package com.example.task_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "projects")
public class Project {

    @Id
    private String id;
    private String name;
    private String description;
    private List<String> taskIds;
    private List<String> memberIds;
    private Long ownerId; // Add this field if you need to query by ownerId

    // No-argument constructor
    public Project() {}

    // Parameterized constructor
    public Project(String id, String name, String description, List<String> taskIds, List<String> memberIds, Long ownerId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.taskIds = taskIds;
        this.memberIds = memberIds;
        this.ownerId = ownerId;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTaskIds() {
        return taskIds;
    }

    public void setTaskIds(List<String> taskIds) {
        this.taskIds = taskIds;
    }

    public List<String> getMemberIds() {
        return memberIds;
    }

    public void setMemberIds(List<String> memberIds) {
        this.memberIds = memberIds;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }
}
