package com.example.task_management.service;

import com.example.task_management.model.Project;
import com.example.task_management.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;
    


    public Project createProject(Project project) {
        return projectRepository.save(project);
    }

    public List<Project> getProjectsForUser(Long userId) {
        return projectRepository.findByOwnerId(userId);
    }
    
    public Project getProjectById(String id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Project not found with id: " + id));
    }
    
}
