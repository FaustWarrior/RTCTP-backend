package com.example.task_management.graphql.resolver;

import com.example.task_management.model.User;
import com.example.task_management.service.UserService;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserResolver {

    @Autowired
    private UserService userService;

    public DataFetcher<User> getUserById() {
        return dataFetchingEnvironment -> {
            // Ensure the ID argument is properly retrieved and converted
            String id = dataFetchingEnvironment.getArgument("id");
            return userService.getUserById(id);
        };
    }

    public DataFetcher<User> createUser() {
        return dataFetchingEnvironment -> {
            // Ensure the user argument is properly retrieved and converted
            // Adjust if necessary based on how the User object is expected from the GraphQL input
            User user = dataFetchingEnvironment.getArgument("user");
            return userService.createUser(user);
        };
    }
}
