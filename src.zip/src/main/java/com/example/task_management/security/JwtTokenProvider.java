package com.example.task_management.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.stereotype.Component;
import com.nimbusds.jose.jwk.source.ImmutableSecret;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    private JwtEncoder jwtEncoder;
    private JwtDecoder jwtDecoder;

    @Value("${jwt.key}")
    private String secretKey;

    private final CustomUserDetailsService customUserDetailsService;

    public JwtTokenProvider(CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }

    @jakarta.annotation.PostConstruct
    public void init() {
        if (secretKey == null || secretKey.isEmpty()) {
            throw new IllegalStateException("JWT secret key is not set");
        }

        // Create the SecretKey from the secret key
        byte[] keyBytes = secretKey.getBytes(); // Convert your secret key string to bytes
        SecretKey key = new SecretKeySpec(keyBytes, "HmacSHA256");

        // Initialize the JwtEncoder and JwtDecoder
        this.jwtEncoder = new NimbusJwtEncoder(new ImmutableSecret<>(key));
        this.jwtDecoder = NimbusJwtDecoder.withSecretKey(key).macAlgorithm(MacAlgorithm.HS256).build();
        
        logger.info("JWT Token Provider initialized with secret key");
    }

    public String createToken(String username, Map<String, Object> claims) {
        JwtClaimsSet.Builder claimsBuilder = JwtClaimsSet.builder()
                .subject(username)
                .issuedAt(Instant.now())
                .expiresAt(Instant.now().plusSeconds(3600)); // 1 hour validity

        claims.forEach(claimsBuilder::claim);

        JwtClaimsSet claimsSet = claimsBuilder.build();
        JwtEncoderParameters parameters = JwtEncoderParameters.from(claimsSet);

        return jwtEncoder.encode(parameters).getTokenValue();
    }

    public boolean validateToken(String token) {
        try {
            jwtDecoder.decode(token);
            return true;
        } catch (JwtException e) {
            // Log the exception or add additional handling if needed
            logger.error("Invalid JWT token", e);
            return false; // Token is invalid
        }
    }

    public Authentication getAuthentication(String token) {
        Jwt jwt = jwtDecoder.decode(token);
        String username = jwt.getSubject(); // Assuming "sub" is the username

        UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);

        return new UsernamePasswordAuthenticationToken(userDetails, token, userDetails.getAuthorities());
    }

    public String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}
