package com.example.task_management.graphql.resolver;

import com.example.task_management.model.Task;
import com.example.task_management.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TaskResolver {

    @Autowired
    private TaskService taskService;

    public List<Task> getTasksForUser(String userId) {
        return taskService.getTasksForUser(userId);
    }
}
