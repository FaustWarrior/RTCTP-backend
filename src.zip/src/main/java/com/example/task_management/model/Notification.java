package com.example.task_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "notifications") // This annotation maps the class to a MongoDB collection.
public class Notification {

    @Id
    private String id; // MongoDB document ID (automatically generated).
    private Long userId; // The ID of the user receiving the notification.
    private String message; // The notification message.
    private boolean read; // To indicate if the notification has been read or not.
    private LocalDateTime createdAt; // Timestamp for when the notification was created.

    // Constructors
    public Notification() {}

    public Notification(Long userId, String message) {
        this.userId = userId;
        this.message = message;
        this.read = false; // Initially, notifications are unread.
        this.createdAt = LocalDateTime.now(); // Set the current timestamp.
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
