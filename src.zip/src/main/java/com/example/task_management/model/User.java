package com.example.task_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Set;
import java.util.Objects;

@Document(collection = "users")
public class User {

    @Id
    private String id;

    private String username;
    private String email;
    private String role;

    private Set<String> taskIds;
    private Set<String> projectIds;

    // No-args constructor
    public User() {
    }

    // All-args constructor
    public User(String id, String username, String email, String role, Set<String> taskIds, Set<String> projectIds) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.role = role;
        this.taskIds = taskIds;
        this.projectIds = projectIds;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Set<String> getTaskIds() {
        return taskIds;
    }

    public void setTaskIds(Set<String> taskIds) {
        this.taskIds = taskIds;
    }

    public Set<String> getProjectIds() {
        return projectIds;
    }

    public void setProjectIds(Set<String> projectIds) {
        this.projectIds = projectIds;
    }

    // toString method
    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", taskIds=" + taskIds +
                ", projectIds=" + projectIds +
                '}';
    }

    // equals method
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id) &&
                Objects.equals(username, user.username) &&
                Objects.equals(email, user.email) &&
                Objects.equals(role, user.role) &&
                Objects.equals(taskIds, user.taskIds) &&
                Objects.equals(projectIds, user.projectIds);
    }

    // hashCode method
    @Override
    public int hashCode() {
        return Objects.hash(id, username, email, role, taskIds, projectIds);
    }
}
