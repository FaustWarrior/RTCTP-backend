package com.example.task_management.repository;

import com.example.task_management.model.Notification;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends MongoRepository<Notification, String> {

    // Custom query method to find notifications by userId
    List<Notification> findByUserId(Long userId);
}
