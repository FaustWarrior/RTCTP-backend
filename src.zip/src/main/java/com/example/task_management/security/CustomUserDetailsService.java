package com.example.task_management.security;

import com.example.task_management.model.User;
import com.example.task_management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Convert User into UserDetails
        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password("N/A") // As MongoDB version does not store the password
                .authorities(convertRolesToAuthorities(user.getRole())) // Convert role to authorities
                .build();
    }

    // Helper method to convert role to authorities
    private Set<SimpleGrantedAuthority> convertRolesToAuthorities(String role) {
        return Set.of(new SimpleGrantedAuthority(role));
    }
}
