package com.example.task_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Objects;

@Document(collection = "analytics")
public class Analytics {

    @Id
    private String id;

    private String taskId;
    private String projectId;
    private String userId;
    private String metric;
    private Long value;

    // No-args constructor
    public Analytics() {
    }

    // All-args constructor
    public Analytics(String id, String taskId, String projectId, String userId, String metric, Long value) {
        this.id = id;
        this.taskId = taskId;
        this.projectId = projectId;
        this.userId = userId;
        this.metric = metric;
        this.value = value;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    // toString method
    @Override
    public String toString() {
        return "Analytics{" +
                "id='" + id + '\'' +
                ", taskId='" + taskId + '\'' +
                ", projectId='" + projectId + '\'' +
                ", userId='" + userId + '\'' +
                ", metric='" + metric + '\'' +
                ", value=" + value +
                '}';
    }

    // equals method
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Analytics analytics = (Analytics) o;
        return Objects.equals(id, analytics.id) &&
                Objects.equals(taskId, analytics.taskId) &&
                Objects.equals(projectId, analytics.projectId) &&
                Objects.equals(userId, analytics.userId) &&
                Objects.equals(metric, analytics.metric) &&
                Objects.equals(value, analytics.value);
    }

    // hashCode method
    @Override
    public int hashCode() {
        return Objects.hash(id, taskId, projectId, userId, metric, value);
    }
}
