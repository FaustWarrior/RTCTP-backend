package com.example.task_management.controller;

import com.example.task_management.model.Analytics;
import com.example.task_management.service.AnalyticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {

    @Autowired
    private AnalyticsService analyticsService;

    // Get overall analytics for the project
    @GetMapping
    public ResponseEntity<Analytics> getProjectAnalytics() {
        Analytics analytics = analyticsService.getProjectAnalytics();
        return ResponseEntity.ok(analytics); // Return 200 OK with the analytics data
    }

    // Get analytics for a specific project
    @GetMapping("/{projectId}")
    public ResponseEntity<Analytics> getProjectAnalyticsForProject(@PathVariable String projectId) {
        Analytics analytics = analyticsService.getProjectAnalyticsForProject(projectId);
        return ResponseEntity.ok(analytics); // Return 200 OK with the project-specific analytics
    }
}
