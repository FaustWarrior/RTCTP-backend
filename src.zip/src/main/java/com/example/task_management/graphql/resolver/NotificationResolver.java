package com.example.task_management.graphql.resolver;

import com.example.task_management.model.Notification;
import com.example.task_management.service.NotificationService;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class NotificationResolver {

    @Autowired
    private NotificationService notificationService;

    public DataFetcher<Notification> getNotificationById() {
        return dataFetchingEnvironment -> {
            String id = dataFetchingEnvironment.getArgument("id");
            return notificationService.getNotificationById(id);
        };
    }

    public DataFetcher<Notification> createNotification() {
        return dataFetchingEnvironment -> {
            Notification notification = dataFetchingEnvironment.getArgument("notification");
            return notificationService.createNotification(notification);
        };
    }
    
    public DataFetcher<List<Notification>> getNotificationsForUser() {
        return dataFetchingEnvironment -> {
            Long userId = dataFetchingEnvironment.getArgument("userId");
            return notificationService.getNotificationsForUser(userId);
        };
    }
}
